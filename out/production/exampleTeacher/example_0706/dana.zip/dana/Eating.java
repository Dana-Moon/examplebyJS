package example_0706.dana;

public interface Eating {
    void eat(String human);
}
